# -*- coding: utf-8 -*-
from fabric.api import *


# 设置变量
host = "192.168.31.9"
port = "22"
user = "micllo"
passwd = "abc123"
pro_name = "pythonApi"
tmp_path = "/Users/micllo/Downloads"


# 本地操作
def local_action():

    # 清空临时目录中的内容, 将项目代码拷贝入临时文件夹
    with lcd(tmp_path):
        local("pwd")


# 服务器端操作
def server_action():
    with settings(host_string="%s@%s:%s" % (user, host, port), password=passwd):
        run("pwd")


if __name__ == "__main__":
    local_action()
    server_action()



