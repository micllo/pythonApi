//【 安 装 步 骤 】
// 1.创建package.json文件（项目根目录下执行）：npm init

// 2.局部(项目下)安装 需要的工具包（ 项目根目录下生成 node_modules 目录）
// npm install gulp@3.9.1 --save-dev --registry=https://registry.npm.taobao.org
// npm install run-sequence@1.2.2 --save-dev --registry=https://registry.npm.taobao.org
// npm install browser-sync@2.18.6 --save-dev --registry=https://registry.npm.taobao.org
// npm install sleep@5.2.3 --save-dev --registry=https://registry.npm.taobao.org
// npm install gulp-rev@7.1.2 --save-dev --registry=https://registry.npm.taobao.org
// npm install gulp-clean@0.3.2 --save-dev --registry=https://registry.npm.taobao.org
// npm install gulp-rev-collector@1.1.1 --save-dev --registry=https://registry.npm.taobao.org
// npm install gulp-html-replace@1.6.2 --save-dev --registry=https://registry.npm.taobao.org

// ################################ 或  者 ################################

// 2.局部(项目下)安装 需要的 cnpm 工具包（ 项目根目录下生成 node_modules 目录）
//   npm install cnpm --registry=https://registry.npm.taobao.org

// 3.之后就可以使用cnpm命令 局部安装需要的依赖包 （无需再使用淘宝镜像源）
// cnpm install gulp@3.9.1 --save-dev
// cnpm install run-sequence@1.2.2 --save-dev
// cnpm install browser-sync@2.18.6 --save-dev
// cnpm install sleep@5.2.3 --save-dev
// cnpm install gulp-rev@7.1.2 --save-dev
// cnpm install gulp-clean@0.3.2 --save-dev
// cnpm install gulp-rev-collector@1.1.1 --save-dev
// cnpm install gulp-html-replace@1.6.2 --save-dev


// 获取 node_modules 中相应的包
var gulp = require('gulp');
var child_process_exec = require('child_process').exec;
var run_sequence = require('run-sequence');
var browserSync = require('browser-sync').create();
var sleep = require('sleep');
var gulp_rev = require('gulp-rev');
var gulp_clean = require('gulp-clean');
var gulp_rev_collector = require('gulp-rev-collector');

// 源文件等路径
var src_root = 'Api/';
var src_css_path = src_root + 'static/css/';
var src_css_file = src_css_path + "*.css";
var src_js_path = src_root + 'static/scripts/';
var src_js_file = src_js_path + '*.js';
var src_html_path = src_root + 'templates/';
var src_html_file = src_html_path + '*.html';
var src_fonts_path = src_root + 'static/fonts/';
var src_fonts_file = src_fonts_path + '**';
var src_font_awesome_path = src_root + 'static/font-awesome/';
var src_font_awesome_file = src_font_awesome_path + '**';

// 编译后的路径
var build_root = 'Build/';
var build_css_path = build_root + 'css/';
var build_js_path = build_root + 'scripts/';
var build_html_path = build_root + 'templates/';
var build_fonts_path = build_root + 'fonts/';
var build_font_awesome_path = build_root + 'font-awesome/';
var build_manifest_path = build_root + '**/*.json';


/**
 * 【 清除 编译后的 相关内容 fonts、css、js 】
 */
gulp.task('clean fonts', function () {
    // 删除 编译后的 fonts
    return gulp.src(build_fonts_path)
        .pipe(gulp_clean());
});
gulp.task('clean font-awesome', function () {
    // 删除 编译后的 fonts-awesome
    return gulp.src(build_font_awesome_path)
        .pipe(gulp_clean());
});
gulp.task('clean css', function () {
    // 删除 编译后的 css
    return gulp.src(build_css_path)
        .pipe(gulp_clean());
});
gulp.task('clean js', function () {
    // 删除 编译后的 js
    return gulp.src(build_js_path)
        .pipe(gulp_clean());
});

/**
  【 编译 相关 内容 js、fonts、css 】
    步 骤
    1.将原js文件生成hash编码，并将带有hash编码的新js文件存入目标文件夹下
    2.生成rev-manifest.json文件名对照映射，并存入目标文件夹下
 */

gulp.task('build js', ['clean js'], function(){
    // 编译 js
    sleep.sleep(1);
    return gulp.src(src_js_file)
        .pipe(gulp_rev())
        .pipe(gulp.dest(build_js_path))
        .pipe(gulp_rev.manifest())
        .pipe(gulp.dest(build_js_path));
});
gulp.task('build fonts', ['clean fonts'], function () {
    // 编译 fonts : 不做rev hash，本身fonts 和 CSS 相连，没必要修改
    sleep.sleep(1);
    return gulp.src(src_fonts_file)
        .pipe(gulp.dest(build_fonts_path))
        .pipe(gulp_rev.manifest())
        .pipe(gulp.dest(build_fonts_path));
});
gulp.task('build font-awesome', ['clean font-awesome'], function () {
    // 编译 font-awesome : 不做rev hash，本身fonts 和 CSS 相连，没必要修改
    sleep.sleep(1);
    return gulp.src(src_font_awesome_file)
        .pipe(gulp.dest(build_font_awesome_path))
        .pipe(gulp_rev.manifest())
        .pipe(gulp.dest(build_font_awesome_path));
});
gulp.task('build css', ['clean css'], function(){
    // 编译 css
    sleep.sleep(1);
    return gulp.src(src_css_file)
        .pipe(gulp_rev())
        .pipe(gulp.dest(build_css_path))
        .pipe(gulp_rev.manifest())
        .pipe(gulp.dest(build_css_path));
});

/**
 * 【 编译 相关 内容 html 】
 *  1.将 原 路径的html拷贝入 build 路径中
 *  2.通过 已经生成的 manifest 映射文件，修改html中的 js，css 路径
 */
gulp.task('build html', function(){
    // 编译 html，修改js,css路径改成 build后路径
    sleep.sleep(1);
    return gulp.src([build_manifest_path, src_html_file])
        .pipe(gulp_rev_collector({
            replaceReved: true,
            dirReplacements: {
                "static/css/": build_css_path,
                "static/scripts/": build_js_path
            }
        }))
        .pipe(gulp.dest(build_html_path));
});

/**
 * 【 整体编译静态文件 防止浏览器缓存js 】
 */
gulp.task('build static file', function () {
     run_sequence('build fonts', 'build font-awesome', 'build css', 'build js', 'build html');
});

gulp.task('run deploy', function () {
    child_process_exec("python3 deploy.py");
});

/**
 * 【 编译后，部署 docker 服务器 】
 */
gulp.task('deploy docker', function () {
    run_sequence("build static file", "run deploy");
});



// ##############################################################################################



// 设置相关变量
var kill_cmd_suffix = " | grep -v 'grep' | awk '{print $2}' | xargs kill -9 ";

// 启动/停止 MongoDB 服务
gulp.task('start mongodb', function () {
	child_process_exec('/Users/micllo/Documents/tools/mongodb/bin/mongod -f /Users/micllo/Documents/tools/mongodb/bin/mongodb.conf')
});
gulp.task('stop mongodb', function(){
	child_process_exec("ps aux | grep mongo" + kill_cmd_suffix)
});

// 启动/停止 Nginx 服务
gulp.task('start nginx', function () {
	child_process_exec('nohup sudo nginx > /dev/null 2>&1 &');
});
gulp.task('stop nginx', function(){
	child_process_exec("sudo nginx -s stop")
});
/**
 【 备 注 】
  MAC本地安装的 nginx 相关路径
  默认安装路径：/usr/local/Cellar/nginx/1.15.5/
  默认配置文件路径：/usr/local/etc/nginx/
  启动命令：sudo nginx
 */

// 启动/停止 uWSGI 服务
gulp.task('start uwsgi', function () {
    child_process_exec("sh start_uwsgi_local.sh");
	// child_process_exec("nohup uwsgi --master --emperor /Users/micllo/Documents/works/GitHub/pythonApi/vassals_local" +
	// 	" --die-on-term --logto /Users/micllo/Documents/works/GitHub/pythonApi/Logs/emperor.log > /dev/null 2>&1 &");
});
gulp.task('stop uwsgi', function(){
	child_process_exec("ps aux | grep uwsgi" + kill_cmd_suffix)
});


// ################### 整 体 启动 / 停止 ###################

gulp.task('start env', function () {
     run_sequence('start mongodb', 'start nginx', 'start uwsgi');
});
gulp.task('stop env', function () {
     run_sequence('stop uwsgi', 'stop nginx', 'stop mongodb');
});

// 启动命令：gulp "start env"
// 停止命令：gulp "stop env"


// ################### 页 面 调 试 ###################


// 命令 gulp "html debug" （ 启动前会先执行 "start env" 任务 ）
gulp.task('html debug', ['start env', 'build static file'], function () {
    // 启动代理浏览器
    sleep.sleep(5);
    browserSync.init({
        notify: true,
        proxy: "http://localhost:7060/api_local/API/get_project_case_info/pro_demo_1",
        // proxy: "http://127.0.0.1:7060/api_local/API/get_test_report/pro_demo_1",
        // proxy: "http://localhost:7060/api_local/API/index",
        port: 1122,
        open: "local",
        browser: "google chrome"
    });


    // 监听经常变动的文件，若有变动，则重启'uwsgi服务'和'自动刷新浏览器'
    //（ 注意：由于'function'中的操作步骤几乎是同时进行的，所以'setTimeout'中设置的超时时间要 大于 以上步骤的总执行时间 ）
    gulp.watch(
        [
            'Api/templates/*.*',
            'Api/static/css/*.*',
            'Api/static/scripts/*.*',
            'Api/api_services/*.*',
            'Common/*.*',
            'Config/*.*',
            'TestBase/*.*',
            'Tools/*.*'

        ], function () {
            // 构建静态文件，防止浏览器缓存js
            run_sequence("build static file")
            var ct = new Date();
            var ct_str = ct.getFullYear() + "-" + (ct.getMonth() + 1 ) + "-" + ct.getDate() + " " + ct.getHours() + ":" + ct.getMinutes() + ":" + ct.getSeconds();
            var console_header = "[" + ct_str + "]: ";
            console.log(console_header + "uWSGI restart...");
            child_process_exec("sh stop_uwsgi_local.sh");
            sleep.sleep(1);
            child_process_exec("sh start_uwsgi_local.sh");
            sleep.sleep(1);
            // 等待x秒后 自动刷新浏览器
            setTimeout(function () {
                browserSync.reload();
                console.log(console_header + "Restart Browser...[DONE]");
            }, 8000);
        });
});